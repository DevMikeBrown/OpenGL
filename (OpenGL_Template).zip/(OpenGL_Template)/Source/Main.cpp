#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

int main()
{
    
	return 0;
}