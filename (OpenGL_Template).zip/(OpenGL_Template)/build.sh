cd "$(dirname "$0")"
mkdir build
cd build
cmake -G "MinGW Makefiles" ..
mingw32-make
./Application.exe
